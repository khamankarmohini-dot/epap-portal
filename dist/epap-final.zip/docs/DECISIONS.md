# Architectural & Implementation Decisions (`docs/DECISIONS.md`)

**Project:** EPAP — Examination & Predictive Analytics Portal (PHP 8.1+ / MySQL 8)  
**Date:** 2026-11-25

---

## 1. Workspace & Directory Layout
- The project is extracted and built inside `epap/` within the workspace (`c:\Users\DELL\Documents\CivicConnect\epap`), keeping it isolated from unrelated repository files.
- Root acts as the web root (`index.html`, `login.html`, etc. at `/`), with `/api/*` routed to `api/index.php` via `.htaccess` (Apache) and `router.php` (PHP built-in server).
- Sensitive directories (`app/`, `storage/`, `database/`, `docs/`, `.env`, `tests/`) are blocked from direct HTTP access in both `.htaccess` and `router.php`.

## 2. Mailer Strategy (PHPMailer vs Fallback)
- Plain PHP `Mailer` class supports:
  1. **PHPMailer via Composer** (`vendor/autoload.php`) if installed and `MAIL_DRIVER=smtp`.
  2. **Built-in socket SMTP client** (STARTTLS/TLS AUTH LOGIN) or **PHP `mail()` + `storage/mail/` `.eml`/`.log` file logger** when Composer/PHPMailer is not installed or `APP_ENV=local` / `MAIL_DRIVER=log`.
- In `APP_ENV=local`, OTPs are always logged to `storage/mail/otp.log` and `devOtp` is returned in the login/resend JSON response so the existing `verify-otp.html` auto-fill continues to work seamlessly. In `production`, `devOtp` is never returned.

## 3. SPPU 10-Point Grading & SGPA/CGPA Formula
- Subject total is computed as `in_sem (30) + end_sem (70) + practical (50)` = `150` (or `100` when `practical = 0` / no practical component, determined by subject `max_practical > 0` or `practical > 0`).
- Percentage `P = (obtained / max_total) * 100`.
- SPPU 10-Point Relative/Absolute Grade Scale used:
  - `P >= 85`: Grade `O` (Outstanding), Grade Point `10`
  - `75 <= P < 85`: Grade `A+` (Excellent), Grade Point `9`
  - `65 <= P < 75`: Grade `A` (Very Good), Grade Point `8`
  - `55 <= P < 65`: Grade `B+` (Good), Grade Point `7`
  - `50 <= P < 55`: Grade `B` (Above Average), Grade Point `6`
  - `45 <= P < 50`: Grade `C` (Average), Grade Point `5`
  - `40 <= P < 45`: Grade `P` (Pass), Grade Point `4`
  - `P < 40` (or `end_sem < 28` when `end_sem` out of 70, or `in_sem + end_sem < 40`): Grade `F` (Fail), Grade Point `0`
- Semester SGPA = `SUM(credits * grade_point) / SUM(credits)` (defaulting to equal credits `4` per subject when `subjects.credits` is uniform, or using `subjects.credits`).
- Cumulative CGPA = weighted average of SGPA across all **published** semesters for the student.

## 4. Explainable Predictive Analytics Model
- Implemented in `AnalyticsController`:
  - Uses historical **published** semester SGPAs, current semester continuous assessment / in-sem percentage, and assignment submission timeliness rate.
  - Formula: `Predicted_SGPA = 0.60 * Baseline_CGPA + 0.25 * (InSem_Pct / 10) + 0.15 * (Timely_Rate * 10)` adjusted by linear regression slope across prior semesters (clamped to `[0.00, 10.00]`).
  - Returns explicit `factors` array (weights, raw inputs, contribution) and `confidence` score + `enough_data` boolean. If a student has `< 2` semesters of marks and no submissions, returns `enough_data: false` with a clear message instead of fabricating predictions.

## 5. Authentication, CSRF & Session Hardening
- Sessions configured with `cookie_httponly=1`, `cookie_samesite=Lax`, `use_strict_mode=1`, `cookie_secure` when HTTPS is detected, and a 2-hour (`7200s`) idle timeout enforced server-side.
- `session_regenerate_id(true)` called on login and OTP verification.
- CSRF token stored in `$_SESSION['csrf_token']`, exposed via `GET /api/auth/csrf` and `GET /api/auth/me`, and validated via `X-CSRF-Token` header on all state-changing `/api/*` requests (except `/api/auth/login` which also enforces SameSite + Origin/Referer check, or fetches CSRF token first via `api.js`).
- `must_change_password`: Students created via admin/bulk CSV import have `must_change_password = 1`; `/api/auth/me` exposes `must_change_password` and the frontend prompts/redirects to `profile.html` to update password.

## 6. Coding Practice & Judge0
- All coding problems and test cases are stored in MySQL (`practice_problems`, `practice_testcases`, `practice_submissions`).
- `Judge0Client` reads `JUDGE0_URL` and `JUDGE0_API_KEY` from `.env`. When unconfigured, `/api/practice/run` and `/api/practice/submit` run in explicit **demo mode** (`mode: "demo"`) returning a clear informational notice that Judge0 is not configured rather than faking test case passes. Student code is never executed via `exec()`/`shell_exec()`.

## 7. Configurable Base Path
- `assets/js/api.js` detects `window.EPAP_BASE_PATH` (default `''` for root virtual host or `php -S localhost:3000 router.php`), and `README.md` documents both `php -S` and Apache VirtualHost setup.
