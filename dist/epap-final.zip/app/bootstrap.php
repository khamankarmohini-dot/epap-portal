<?php
/**
 * EPAP - Application Bootstrap
 */
declare(strict_types=1);

define('EPAP_ROOT', dirname(__DIR__));

// Simple PSR-4 autoloader for App\ namespace
spl_autoload_register(function (string $class): void {
    $prefix = 'App\\';
    if (!str_starts_with($class, $prefix)) {
        return;
    }
    $rel = substr($class, strlen($prefix));
    $file = EPAP_ROOT . '/app/' . str_replace('\\', '/', $rel) . '.php';
    if (is_file($file)) {
        require_once $file;
    }
});

use App\Core\Env;
use App\Core\Logger;
use App\Core\Response;

Env::load(EPAP_ROOT . '/.env');

date_default_timezone_set('Asia/Kolkata');

ini_set('display_errors', '0');
ini_set('log_errors', '1');
$logDir = EPAP_ROOT . '/storage/logs';
if (!is_dir($logDir)) {
    @mkdir($logDir, 0775, true);
}
ini_set('error_log', $logDir . '/php_errors.log');

// Central exception & error handlers for HTTP requests
if (PHP_SAPI !== 'cli') {
    set_exception_handler(function (Throwable $e): void {
        Logger::error('Uncaught exception: ' . $e->getMessage(), [
            'file' => $e->getFile(),
            'line' => $e->getLine(),
        ]);
        if (!headers_sent()) {
            Response::error('An internal server error occurred.', 500);
        }
    });

    set_error_handler(function (int $severity, string $message, string $file, int $line): bool {
        if (!(error_reporting() & $severity)) {
            return false;
        }
        throw new ErrorException($message, 0, $severity, $file, $line);
    });

    // Hardened session configuration
    $lifetime = (int) Env::get('SESSION_LIFETIME', '7200');
    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['SERVER_PORT'] ?? '') === '443');
    $secure = Env::get('SESSION_SECURE', 'false') === 'true' ? true : $isHttps;

    if (session_status() === PHP_SESSION_NONE) {
        session_name('EPAP_SESSID');
        session_set_cookie_params([
            'lifetime' => 0,
            'path' => '/',
            'domain' => '',
            'secure' => $secure,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        ini_set('session.use_strict_mode', '1');
        ini_set('session.gc_maxlifetime', (string) $lifetime);
        session_start();
    }

    // Enforce idle timeout
    $now = time();
    if (isset($_SESSION['last_activity']) && ($now - (int) $_SESSION['last_activity']) > $lifetime) {
        session_unset();
        session_destroy();
        session_start();
    }
    $_SESSION['last_activity'] = $now;
}
