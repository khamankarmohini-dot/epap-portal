<?php
declare(strict_types=1);

namespace App\Core;

use PDO;

class Logger
{
    public static function error(string $message, array $context = []): void
    {
        self::write('ERROR', $message, $context);
    }

    public static function info(string $message, array $context = []): void
    {
        self::write('INFO', $message, $context);
    }

    private static function write(string $level, string $message, array $context): void
    {
        $dir = EPAP_ROOT . '/storage/logs';
        if (!is_dir($dir)) {
            @mkdir($dir, 0775, true);
        }
        $line = sprintf(
            "[%s] %s: %s %s\n",
            date('Y-m-d H:i:s'),
            $level,
            $message,
            $context ? json_encode($context, JSON_UNESCAPED_SLASHES) : ''
        );
        @file_put_contents($dir . '/app.log', $line, FILE_APPEND | LOCK_EX);
    }

    public static function audit(PDO $pdo, ?int $userId, string $action, string $detail = '', string $status = 'SUCCESS'): void
    {
        try {
            $ip = Request::clientIp();
            $stmt = $pdo->prepare(
                'INSERT INTO audit_logs (user_id, action, detail, ip, status) VALUES (?,?,?,?,?)'
            );
            $stmt->execute([$userId, $action, $detail, $ip, $status]);
        } catch (\Throwable $e) {
            self::error('Audit log insert failed: ' . $e->getMessage());
        }
    }
}
