<?php
declare(strict_types=1);

namespace App\Core;

use PDO;

class RateLimiter
{
    public static function checkLoginThrottle(PDO $pdo, string $identifier, string $ip, int $maxFailures = 5, int $windowMinutes = 15): void
    {
        $stmt = $pdo->prepare(
            'SELECT COUNT(*) FROM login_attempts
             WHERE (identifier = ? OR ip = ?) AND success = 0
               AND created_at > DATE_SUB(NOW(), INTERVAL ? MINUTE)'
        );
        $stmt->execute([$identifier, $ip, $windowMinutes]);
        $failures = (int) $stmt->fetchColumn();
        if ($failures >= $maxFailures) {
            Response::error('Too many failed login attempts. Please wait 15 minutes before trying again.', 429);
        }
    }

    public static function recordLoginAttempt(PDO $pdo, string $identifier, string $ip, bool $success): void
    {
        $stmt = $pdo->prepare('INSERT INTO login_attempts (identifier, ip, success) VALUES (?,?,?)');
        $stmt->execute([$identifier, $ip, $success ? 1 : 0]);
    }

    public static function checkSessionRate(string $bucket, int $maxHits, int $windowSeconds): void
    {
        $now = time();
        $key = 'rate_' . $bucket;
        $hits = $_SESSION[$key] ?? [];
        $hits = array_values(array_filter($hits, fn($ts) => ($now - (int) $ts) < $windowSeconds));
        if (count($hits) >= $maxHits) {
            Response::error('Rate limit exceeded. Please wait a moment and try again.', 429);
        }
        $hits[] = $now;
        $_SESSION[$key] = $hits;
    }
}
