<?php
declare(strict_types=1);

namespace App\Core;

class Mailer
{
    public static function sendOtp(string $toEmail, string $fullName, string $otp, string $purpose = 'login'): bool
    {
        $subject = $purpose === 'password_reset'
            ? 'Zeal EPAP - Password Reset OTP'
            : 'Zeal EPAP - 2-Step Login Verification OTP';

        $body = "Hello {$fullName},\n\n"
            . "Your single-use 6-digit EPAP verification code is: {$otp}\n"
            . "This code expires in 5 minutes. Do not share it with anyone.\n\n"
            . "Zeal College of Engineering & Research — Dept. of IT\n";

        $mailDir = EPAP_ROOT . '/storage/mail';
        if (!is_dir($mailDir)) {
            @mkdir($mailDir, 0775, true);
        }

        // Always log to storage/mail/otp.log in local mode
        if (Env::isLocal() || Env::get('MAIL_DRIVER', 'log') === 'log') {
            $logLine = sprintf(
                "[%s] TO: %s (%s) | SUBJECT: %s | OTP: %s\n",
                date('Y-m-d H:i:s'),
                $toEmail,
                $fullName,
                $subject,
                $otp
            );
            @file_put_contents($mailDir . '/otp.log', $logLine, FILE_APPEND | LOCK_EX);
        }

        $driver = Env::get('MAIL_DRIVER', 'log');
        $smtpHost = Env::get('SMTP_HOST', '');

        // Use PHPMailer if installed via Composer
        $autoload = EPAP_ROOT . '/vendor/autoload.php';
        if ($driver === 'smtp' && $smtpHost !== '' && is_file($autoload)) {
            require_once $autoload;
            if (class_exists('\\PHPMailer\\PHPMailer\\PHPMailer')) {
                try {
                    $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
                    $mail->isSMTP();
                    $mail->Host = $smtpHost;
                    $mail->SMTPAuth = true;
                    $mail->Username = (string) Env::get('SMTP_USER', '');
                    $mail->Password = (string) Env::get('SMTP_PASS', '');
                    $enc = Env::get('SMTP_ENCRYPTION', 'tls');
                    $mail->SMTPSecure = $enc === 'ssl' ? 'ssl' : 'tls';
                    $mail->Port = (int) Env::get('SMTP_PORT', '587');
                    $mail->setFrom((string) Env::get('MAIL_FROM_ADDRESS', 'noreply@zealstudy.in'), (string) Env::get('MAIL_FROM_NAME', 'Zeal IT EPAP'));
                    $mail->addAddress($toEmail, $fullName);
                    $mail->Subject = $subject;
                    $mail->Body = $body;
                    $mail->send();
                    return true;
                } catch (\Throwable $e) {
                    Logger::error('PHPMailer failed: ' . $e->getMessage());
                    return false;
                }
            }
        }

        return true;
    }
}
