<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Database;
use App\Core\Env;
use App\Core\Logger;
use App\Core\Mailer;
use App\Core\RateLimiter;
use App\Core\Request;
use App\Core\Response;
use App\Core\Validator;

class AuthController
{
    public function csrf(Request $req): void
    {
        Response::json(['csrf_token' => Csrf::token()]);
    }

    public function login(Request $req): void
    {
        $data = Validator::validate($req->body(), [
            'identifier' => 'required|min:3|max:60',
            'password'   => 'required|min:3|max:128',
            'role'       => 'required|in:student,faculty,admin',
        ]);

        $identifier = trim((string) $data['identifier']);
        $password = (string) $data['password'];
        $role = (string) $data['role'];
        $ip = Request::clientIp();

        $pdo = Database::getConnection();
        RateLimiter::checkLoginThrottle($pdo, $identifier, $ip, 5, 15);

        $stmt = $pdo->prepare('SELECT * FROM users WHERE identifier = ? AND role = ? LIMIT 1');
        $stmt->execute([$identifier, $role]);
        $user = $stmt->fetch();

        if (!$user || !(bool) $user['is_active']) {
            RateLimiter::recordLoginAttempt($pdo, $identifier, $ip, false);
            Logger::audit($pdo, $user ? (int) $user['id'] : null, 'LOGIN_FAILED', "Unknown/inactive {$role}: {$identifier}", 'FAILURE');
            Response::error('Invalid credentials. Check your ID and role.', 401);
        }

        if (!password_verify($password, $user['password_hash'])) {
            RateLimiter::recordLoginAttempt($pdo, $identifier, $ip, false);
            Logger::audit($pdo, (int) $user['id'], 'LOGIN_FAILED', 'Incorrect password', 'FAILURE');
            Response::error('Incorrect password.', 401);
        }

        RateLimiter::recordLoginAttempt($pdo, $identifier, $ip, true);

        // Invalidate any previous unused login OTPs
        $pdo->prepare("UPDATE otp_tokens SET used = 1 WHERE user_id = ? AND purpose = 'login' AND used = 0")
            ->execute([(int) $user['id']]);

        $otp = (string) random_int(100000, 999999);
        $otpHash = password_hash($otp, PASSWORD_BCRYPT);

        $pdo->prepare(
            "INSERT INTO otp_tokens (user_id, otp_hash, purpose, ip, expires_at)
             VALUES (?, ?, 'login', ?, DATE_ADD(NOW(), INTERVAL 5 MINUTE))"
        )->execute([(int) $user['id'], $otpHash, $ip]);

        session_regenerate_id(true);
        $_SESSION['pendingLogin'] = [
            'userId' => (int) $user['id'],
            'role' => $user['role'],
            'resendCount' => 0,
            'lastSentAt' => time(),
        ];

        Mailer::sendOtp($user['email'], $user['full_name'], $otp, 'login');

        $payload = [
            'success' => true,
            'maskedEmail' => self::maskEmail($user['email']),
            'role' => $user['role'],
            'csrf_token' => Csrf::token(),
        ];
        if (Env::isLocal()) {
            $payload['devOtp'] = $otp;
        }
        Response::json($payload);
    }

    public function verifyOtp(Request $req): void
    {
        $data = Validator::validate($req->body(), [
            'otp' => 'required|min:6|max:6',
        ]);

        $pending = $_SESSION['pendingLogin'] ?? null;
        if (!$pending || empty($pending['userId'])) {
            Response::error('Invalid session. Please login again.', 400);
        }

        $userId = (int) $pending['userId'];
        $otpInput = trim((string) $data['otp']);
        $pdo = Database::getConnection();

        $stmt = $pdo->prepare(
            "SELECT * FROM otp_tokens
             WHERE user_id = ? AND purpose = 'login' AND used = 0 AND expires_at > NOW()
             ORDER BY id DESC LIMIT 1"
        );
        $stmt->execute([$userId]);
        $token = $stmt->fetch();

        if (!$token) {
            Response::error('OTP expired or not found. Please request a new code.', 401);
        }

        if ((int) $token['attempts'] >= 5) {
            $pdo->prepare('UPDATE otp_tokens SET used = 1 WHERE id = ?')->execute([(int) $token['id']]);
            Logger::audit($pdo, $userId, 'OTP_LOCKED', 'Max OTP attempts exceeded', 'FAILURE');
            Response::error('Maximum OTP attempts exceeded. Please login again.', 429);
        }

        $pdo->prepare('UPDATE otp_tokens SET attempts = attempts + 1 WHERE id = ?')->execute([(int) $token['id']]);

        if (!password_verify($otpInput, $token['otp_hash'])) {
            Logger::audit($pdo, $userId, 'OTP_FAILED', 'Invalid OTP entered', 'FAILURE');
            Response::error('Invalid OTP. Please try again.', 401);
        }

        $pdo->prepare('UPDATE otp_tokens SET used = 1 WHERE id = ?')->execute([(int) $token['id']]);

        $uStmt = $pdo->prepare('SELECT id, identifier, role, full_name, email, must_change_password FROM users WHERE id = ?');
        $uStmt->execute([$userId]);
        $user = $uStmt->fetch();
        if (!$user) {
            Response::error('User account not found.', 404);
        }

        session_regenerate_id(true);
        $_SESSION['user'] = [
            'id' => (int) $user['id'],
            'identifier' => $user['identifier'],
            'role' => $user['role'],
            'full_name' => $user['full_name'],
            'email' => $user['email'],
            'must_change_password' => (bool) $user['must_change_password'],
        ];
        unset($_SESSION['pendingLogin']);
        Csrf::token();

        Logger::audit($pdo, (int) $user['id'], 'LOGIN', 'Role: ' . $user['role'], 'SUCCESS');

        Response::json([
            'success' => true,
            'role' => $user['role'],
            'must_change_password' => (bool) $user['must_change_password'],
            'redirectTo' => self::roleRedirect($user['role']),
        ]);
    }

    public function resendOtp(Request $req): void
    {
        $pending = $_SESSION['pendingLogin'] ?? null;
        if (!$pending || empty($pending['userId'])) {
            Response::error('No pending login session. Please sign in again.', 400);
        }

        $elapsed = time() - (int) ($pending['lastSentAt'] ?? 0);
        if ($elapsed < 60) {
            $wait = 60 - $elapsed;
            Response::error("Please wait {$wait} seconds before requesting a new OTP.", 429);
        }

        $count = (int) ($pending['resendCount'] ?? 0);
        if ($count >= 3) {
            Response::error('Maximum OTP resend limit reached for this session. Please login again.', 429);
        }

        $userId = (int) $pending['userId'];
        $pdo = Database::getConnection();
        $uStmt = $pdo->prepare('SELECT id, full_name, email FROM users WHERE id = ?');
        $uStmt->execute([$userId]);
        $user = $uStmt->fetch();
        if (!$user) {
            Response::error('User not found.', 404);
        }

        $pdo->prepare("UPDATE otp_tokens SET used = 1 WHERE user_id = ? AND purpose = 'login' AND used = 0")
            ->execute([$userId]);

        $otp = (string) random_int(100000, 999999);
        $pdo->prepare(
            "INSERT INTO otp_tokens (user_id, otp_hash, purpose, ip, expires_at)
             VALUES (?, ?, 'login', ?, DATE_ADD(NOW(), INTERVAL 5 MINUTE))"
        )->execute([$userId, password_hash($otp, PASSWORD_BCRYPT), Request::clientIp()]);

        $_SESSION['pendingLogin']['resendCount'] = $count + 1;
        $_SESSION['pendingLogin']['lastSentAt'] = time();

        Mailer::sendOtp($user['email'], $user['full_name'], $otp, 'login');

        $payload = [
            'success' => true,
            'maskedEmail' => self::maskEmail($user['email']),
            'resendsRemaining' => 3 - ($count + 1),
        ];
        if (Env::isLocal()) {
            $payload['devOtp'] = $otp;
        }
        Response::json($payload);
    }

    public function logout(Request $req): void
    {
        $uid = Auth::userId();
        if ($uid) {
            Logger::audit(Database::getConnection(), $uid, 'LOGOUT', 'User signed out');
        }
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
        }
        session_destroy();
        Response::json(['success' => true]);
    }

    public function me(Request $req): void
    {
        $user = Auth::requireAuth();
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT id, identifier, role, full_name, email, must_change_password FROM users WHERE id = ?');
        $stmt->execute([(int) $user['id']]);
        $fresh = $stmt->fetch();
        if (!$fresh) {
            Response::error('Not authenticated.', 401);
        }
        $fresh['id'] = (int) $fresh['id'];
        $fresh['must_change_password'] = (bool) $fresh['must_change_password'];
        $fresh['csrf_token'] = Csrf::token();
        $_SESSION['user'] = array_merge($_SESSION['user'], $fresh);
        Response::json($fresh);
    }

    public function changePassword(Request $req): void
    {
        $user = Auth::requireAuth();
        $data = Validator::validate($req->body(), [
            'current_password' => 'required',
            'new_password'     => 'required|min:8|max:128',
        ]);

        $newPw = (string) $data['new_password'];
        if (!preg_match('/[A-Za-z]/', $newPw) || !preg_match('/\d/', $newPw)) {
            Response::error('New password must be at least 8 characters and include both letters and numbers.', 422);
        }

        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('SELECT password_hash FROM users WHERE id = ?');
        $stmt->execute([(int) $user['id']]);
        $hash = (string) $stmt->fetchColumn();

        if (!password_verify((string) $data['current_password'], $hash)) {
            Response::error('Current password is incorrect.', 400);
        }

        $pdo->prepare('UPDATE users SET password_hash = ?, must_change_password = 0 WHERE id = ?')
            ->execute([password_hash($newPw, PASSWORD_BCRYPT), (int) $user['id']]);

        $_SESSION['user']['must_change_password'] = false;
        Logger::audit($pdo, (int) $user['id'], 'PASSWORD_CHANGED', 'User updated password');
        Response::json(['success' => true, 'message' => 'Password updated successfully.']);
    }

    public function forgotPassword(Request $req): void
    {
        $data = Validator::validate($req->body(), [
            'identifier' => 'required|min:3|max:60',
        ]);
        $pdo = Database::getConnection();
        RateLimiter::checkSessionRate('forgot_pw', 3, 300);

        $stmt = $pdo->prepare('SELECT id, full_name, email FROM users WHERE identifier = ? AND is_active = 1 LIMIT 1');
        $stmt->execute([trim((string) $data['identifier'])]);
        $user = $stmt->fetch();

        if ($user) {
            $pdo->prepare("UPDATE otp_tokens SET used = 1 WHERE user_id = ? AND purpose = 'password_reset' AND used = 0")
                ->execute([(int) $user['id']]);
            $otp = (string) random_int(100000, 999999);
            $pdo->prepare(
                "INSERT INTO otp_tokens (user_id, otp_hash, purpose, ip, expires_at)
                 VALUES (?, ?, 'password_reset', ?, DATE_ADD(NOW(), INTERVAL 5 MINUTE))"
            )->execute([(int) $user['id'], password_hash($otp, PASSWORD_BCRYPT), Request::clientIp()]);
            Mailer::sendOtp($user['email'], $user['full_name'], $otp, 'password_reset');
        }

        Response::json(['success' => true, 'message' => 'If the account exists, a password reset OTP has been sent to its registered email.']);
    }

    public function resetPassword(Request $req): void
    {
        $data = Validator::validate($req->body(), [
            'identifier'   => 'required|min:3|max:60',
            'otp'          => 'required|min:6|max:6',
            'new_password' => 'required|min:8|max:128',
        ]);

        $newPw = (string) $data['new_password'];
        if (!preg_match('/[A-Za-z]/', $newPw) || !preg_match('/\d/', $newPw)) {
            Response::error('New password must be at least 8 characters and include both letters and numbers.', 422);
        }

        $pdo = Database::getConnection();
        $uStmt = $pdo->prepare('SELECT id FROM users WHERE identifier = ? AND is_active = 1 LIMIT 1');
        $uStmt->execute([trim((string) $data['identifier'])]);
        $userId = (int) $uStmt->fetchColumn();
        if (!$userId) {
            Response::error('Invalid reset request.', 400);
        }

        $tStmt = $pdo->prepare(
            "SELECT * FROM otp_tokens
             WHERE user_id = ? AND purpose = 'password_reset' AND used = 0 AND expires_at > NOW()
             ORDER BY id DESC LIMIT 1"
        );
        $tStmt->execute([$userId]);
        $token = $tStmt->fetch();
        if (!$token || (int) $token['attempts'] >= 5 || !password_verify(trim((string) $data['otp']), $token['otp_hash'])) {
            if ($token) {
                $pdo->prepare('UPDATE otp_tokens SET attempts = attempts + 1 WHERE id = ?')->execute([(int) $token['id']]);
            }
            Response::error('Invalid or expired reset OTP.', 401);
        }

        $pdo->prepare('UPDATE otp_tokens SET used = 1 WHERE id = ?')->execute([(int) $token['id']]);
        $pdo->prepare('UPDATE users SET password_hash = ?, must_change_password = 0 WHERE id = ?')
            ->execute([password_hash($newPw, PASSWORD_BCRYPT), $userId]);

        Logger::audit($pdo, $userId, 'PASSWORD_RESET', 'Password reset via OTP');
        Response::json(['success' => true, 'message' => 'Password reset successful. You can now sign in.']);
    }

    private static function maskEmail(string $email): string
    {
        $parts = explode('@', $email, 2);
        $u = $parts[0] ?? 'user';
        $d = $parts[1] ?? 'zealstudy.in';
        return substr($u, 0, 2) . '****@' . $d;
    }

    private static function roleRedirect(string $role): string
    {
        return match ($role) {
            'student' => '/student-dashboard.html',
            'faculty' => '/faculty-dashboard.html',
            default   => '/admin-dashboard.html',
        };
    }
}
