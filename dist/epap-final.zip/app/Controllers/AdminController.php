<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Core\Database;
use App\Core\Logger;
use App\Core\RateLimiter;
use App\Core\Request;
use App\Core\Response;
use App\Core\SppuGrading;
use App\Core\Validator;

class AdminController
{
    public function stats(Request $req): void
    {
        $pdo = Database::getConnection();
        $students = (int) $pdo->query('SELECT COUNT(*) FROM students s JOIN users u ON s.user_id=u.id WHERE u.is_active=1')->fetchColumn();
        $faculty  = (int) $pdo->query('SELECT COUNT(*) FROM faculty f JOIN users u ON f.user_id=u.id WHERE u.is_active=1')->fetchColumn();
        $subjects = (int) $pdo->query('SELECT COUNT(*) FROM subjects')->fetchColumn();
        $subs     = (int) $pdo->query('SELECT COUNT(*) FROM submissions')->fetchColumn();
        $pending  = (int) $pdo->query("SELECT COUNT(*) FROM submissions WHERE status='submitted'")->fetchColumn();
        $passRate = $pdo->query(
            "SELECT ROUND(AVG(sm.passed) * 100, 1)
             FROM semester_marks sm
             JOIN exam_results_release er ON sm.exam_id = er.id
             WHERE er.status IN ('published','locked')"
        )->fetchColumn();

        Response::json([
            'total_students' => $students,
            'total_faculty' => $faculty,
            'total_subjects' => $subjects,
            'total_submissions' => $subs,
            'pending_grading' => $pending,
            'pass_rate' => $passRate !== null ? (float) $passRate : 0.0,
        ]);
    }

    public function students(Request $req): void
    {
        $pdo = Database::getConnection();
        $q = trim((string) ($req->query('q', '')));
        $sql = 'SELECT s.*, u.full_name, u.email, u.is_active
                FROM students s JOIN users u ON s.user_id = u.id WHERE 1=1';
        $bind = [];
        if ($q !== '') {
            $sql .= ' AND (s.zprn LIKE ? OR u.full_name LIKE ? OR u.email LIKE ?)';
            $like = "%{$q}%";
            $bind = [$like, $like, $like];
        }
        $sql .= ' ORDER BY s.year, s.division, s.roll_no LIMIT 500';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($bind);
        Response::json($stmt->fetchAll());
    }

    public function createStudent(Request $req): void
    {
        $data = Validator::validate($req->body(), [
            'full_name' => 'required|min:2|max:100',
            'email'     => 'required|email|max:120',
            'zprn'      => 'required|min:5|max:60',
            'roll_no'   => 'int|min:0|max:999',
            'division'  => 'in:A,B,C',
            'year'      => 'in:SE-IT,TE-IT,BE-IT',
            'semester'  => 'int|min:1|max:8',
        ]);

        $pdo = Database::getConnection();
        $zprn = trim((string) $data['zprn']);
        $dup = $pdo->prepare('SELECT id FROM users WHERE identifier = ?');
        $dup->execute([$zprn]);
        if ($dup->fetch()) {
            Response::error('Student with this ZPRN already exists.', 409);
        }

        $pdo->beginTransaction();
        try {
            $pdo->prepare(
                'INSERT INTO users (identifier, password_hash, role, full_name, email, must_change_password) VALUES (?,?,?,?,?,1)'
            )->execute([$zprn, password_hash($zprn, PASSWORD_BCRYPT), 'student', trim((string) $data['full_name']), trim((string) $data['email'])]);
            $uid = (int) $pdo->lastInsertId();

            $pdo->prepare(
                'INSERT INTO students (user_id, zprn, roll_no, division, year, semester) VALUES (?,?,?,?,?,?)'
            )->execute([
                $uid,
                $zprn,
                (int) ($data['roll_no'] ?? 0),
                (string) ($data['division'] ?? 'A'),
                (string) ($data['year'] ?? 'TE-IT'),
                (int) ($data['semester'] ?? 5),
            ]);
            $pdo->commit();
            Logger::audit($pdo, Auth::userId(), 'STUDENT_CREATED', "Created {$zprn}");
            Response::json(['success' => true, 'id' => $uid], 201);
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    public function importStudentsCsv(Request $req): void
    {
        RateLimiter::checkSessionRate('csv_import', 10, 300);
        $file = $req->file('file');
        if (!$file || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            Response::error('Please upload a valid CSV file.', 422);
        }
        $ext = strtolower(pathinfo((string) $file['name'], PATHINFO_EXTENSION));
        if ($ext !== 'csv') {
            Response::error('Only .csv files are supported.', 422);
        }

        $handle = fopen($file['tmp_name'], 'r');
        if (!$handle) {
            Response::error('Unable to read uploaded CSV.', 400);
        }

        $header = fgetcsv($handle);
        if (!$header) {
            fclose($handle);
            Response::error('CSV file is empty.', 422);
        }
        $normHeader = array_map(fn($h) => strtolower(trim((string) $h)), $header);
        $requiredCols = ['zprn', 'fullname', 'email', 'year', 'division', 'rollno'];
        foreach ($requiredCols as $col) {
            if (!in_array($col, $normHeader, true)) {
                fclose($handle);
                Response::error("Missing required CSV column: {$col}. Expected: ZPRN, FullName, Email, Year, Division, RollNo", 422);
            }
        }
        $idx = array_flip($normHeader);

        $pdo = Database::getConnection();
        $created = 0;
        $skipped = 0;
        $errors = 0;
        $report = [];

        $checkUser = $pdo->prepare('SELECT id FROM users WHERE identifier = ?');
        $insUser = $pdo->prepare(
            'INSERT INTO users (identifier, password_hash, role, full_name, email, must_change_password) VALUES (?,?,?,?,?,1)'
        );
        $insStu = $pdo->prepare(
            'INSERT INTO students (user_id, zprn, roll_no, division, year, semester) VALUES (?,?,?,?,?,?)'
        );

        $pdo->beginTransaction();
        try {
            $rowNum = 1;
            while (($row = fgetcsv($handle)) !== false) {
                $rowNum++;
                if (count(array_filter($row, fn($v) => trim((string) $v) !== '')) === 0) {
                    continue;
                }
                $zprn     = trim((string) ($row[$idx['zprn']] ?? ''));
                $fullName = trim((string) ($row[$idx['fullname']] ?? ''));
                $email    = trim((string) ($row[$idx['email']] ?? ''));
                $year     = strtoupper(trim((string) ($row[$idx['year']] ?? 'TE-IT')));
                $division = strtoupper(trim((string) ($row[$idx['division']] ?? 'A')));
                $rollNo   = (int) trim((string) ($row[$idx['rollno']] ?? '0'));

                if ($zprn === '' || $fullName === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $errors++;
                    $report[] = ['row' => $rowNum, 'zprn' => $zprn, 'status' => 'error', 'reason' => 'Invalid ZPRN, FullName, or Email'];
                    continue;
                }
                if (!in_array($year, ['SE-IT', 'TE-IT', 'BE-IT'], true)) {
                    $year = 'TE-IT';
                }
                if (!in_array($division, ['A', 'B', 'C'], true)) {
                    $division = 'A';
                }

                $checkUser->execute([$zprn]);
                if ($checkUser->fetch()) {
                    $skipped++;
                    $report[] = ['row' => $rowNum, 'zprn' => $zprn, 'status' => 'skipped', 'reason' => 'Duplicate ZPRN'];
                    continue;
                }

                $sem = $year === 'SE-IT' ? 3 : ($year === 'BE-IT' ? 7 : 5);
                $insUser->execute([$zprn, password_hash($zprn, PASSWORD_BCRYPT), 'student', $fullName, $email]);
                $uid = (int) $pdo->lastInsertId();
                $insStu->execute([$uid, $zprn, $rollNo, $division, $year, $sem]);
                $created++;
                $report[] = ['row' => $rowNum, 'zprn' => $zprn, 'status' => 'created', 'reason' => 'Enrolled'];
            }
            $pdo->commit();
        } catch (\Throwable $e) {
            $pdo->rollBack();
            fclose($handle);
            throw $e;
        }
        fclose($handle);

        Logger::audit($pdo, Auth::userId(), 'STUDENTS_BULK_IMPORT', "Created: {$created}, Skipped: {$skipped}, Errors: {$errors}");
        Response::json([
            'success' => true,
            'created' => $created,
            'skipped' => $skipped,
            'errors' => $errors,
            'rows' => $report,
        ]);
    }

    public function downloadStudentTemplate(Request $req): void
    {
        Response::csv(
            'epap_student_import_template.csv',
            ['ZPRN', 'FullName', 'Email', 'Year', 'Division', 'RollNo'],
            [
                ['ZCOER-IT-2023-071', 'Snehal P. Kulkarni', 'snehal.kulkarni2023@zealstudy.in', 'TE-IT', 'A', '71'],
                ['ZCOER-IT-2023-072', 'Omkar V. Deshpande', 'omkar.deshpande2023@zealstudy.in', 'TE-IT', 'B', '72'],
            ]
        );
    }

    public function faculty(Request $req): void
    {
        $pdo = Database::getConnection();
        $rows = $pdo->query(
            'SELECT f.*, u.full_name, u.email, u.is_active
             FROM faculty f JOIN users u ON f.user_id = u.id
             ORDER BY u.full_name'
        )->fetchAll();
        Response::json($rows);
    }

    public function subjects(Request $req): void
    {
        $pdo = Database::getConnection();
        $rows = $pdo->query('SELECT * FROM subjects ORDER BY semester, code')->fetchAll();
        Response::json($rows);
    }

    public function allocations(Request $req): void
    {
        $pdo = Database::getConnection();
        $rows = $pdo->query(
            "SELECT fa.*, f.faculty_id AS staff_code, u.full_name AS faculty_name,
                    s.code AS subject_code, s.name AS subject_name,
                    (SELECT COUNT(*) FROM students st WHERE st.year = fa.year AND st.division = fa.division) AS assigned_students
             FROM faculty_allocations fa
             JOIN faculty f ON fa.faculty_id = f.id
             JOIN users u ON f.user_id = u.id
             JOIN subjects s ON fa.subject_id = s.id
             ORDER BY fa.year, fa.division, s.code"
        )->fetchAll();
        Response::json($rows);
    }

    public function createAllocation(Request $req): void
    {
        $data = Validator::validate($req->body(), [
            'faculty_id'    => 'required|int',
            'subject_id'    => 'required|int',
            'year'          => 'required|in:SE-IT,TE-IT,BE-IT',
            'division'      => 'required|in:A,B,C',
            'academic_year' => 'max:20',
        ]);

        $pdo = Database::getConnection();
        $acadYear = (string) ($data['academic_year'] ?? '2025-26');

        $chk = $pdo->prepare(
            'SELECT id FROM faculty_allocations WHERE faculty_id=? AND subject_id=? AND year=? AND division=? AND academic_year=?'
        );
        $chk->execute([(int) $data['faculty_id'], (int) $data['subject_id'], $data['year'], $data['division'], $acadYear]);
        if ($chk->fetch()) {
            Response::error('This faculty allocation already exists.', 409);
        }

        $pdo->prepare(
            "INSERT INTO faculty_allocations (faculty_id, subject_id, year, division, academic_year, status)
             VALUES (?,?,?,?,?,'active')"
        )->execute([(int) $data['faculty_id'], (int) $data['subject_id'], $data['year'], $data['division'], $acadYear]);

        $newId = (int) $pdo->lastInsertId();
        Logger::audit($pdo, Auth::userId(), 'FACULTY_ALLOCATION_CREATED', "Allocation #{$newId} ({$data['year']} Div {$data['division']})");
        Response::json(['success' => true, 'id' => $newId], 201);
    }

    public function deleteAllocation(Request $req, array $params): void
    {
        $id = (int) ($params['id'] ?? 0);
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare('DELETE FROM faculty_allocations WHERE id = ?');
        $stmt->execute([$id]);
        if ($stmt->rowCount() === 0) {
            Response::error('Allocation not found.', 404);
        }
        Logger::audit($pdo, Auth::userId(), 'FACULTY_ALLOCATION_DELETED', "Allocation #{$id}");
        Response::json(['success' => true]);
    }

    public function exams(Request $req): void
    {
        $pdo = Database::getConnection();
        $rows = $pdo->query(
            'SELECT er.*,
                    COUNT(DISTINCT sm.student_id) AS candidates_count,
                    ROUND(AVG(sm.passed) * 100, 1) AS pass_percentage
             FROM exam_results_release er
             LEFT JOIN semester_marks sm ON sm.exam_id = er.id
             GROUP BY er.id
             ORDER BY er.semester DESC, er.id DESC'
        )->fetchAll();
        Response::json($rows);
    }

    public function updateExamStatus(Request $req, array $params): void
    {
        $id = (int) ($params['id'] ?? 0);
        $data = Validator::validate($req->body(), [
            'status' => 'required|in:draft,under_moderation,published,locked',
        ]);
        $status = (string) $data['status'];

        $pdo = Database::getConnection();
        $chk = $pdo->prepare('SELECT exam_name FROM exam_results_release WHERE id = ?');
        $chk->execute([$id]);
        $exam = $chk->fetch();
        if (!$exam) {
            Response::error('Exam session not found.', 404);
        }

        if ($status === 'published') {
            $pdo->prepare('UPDATE exam_results_release SET status = ?, published_at = NOW(), published_by = ? WHERE id = ?')
                ->execute([$status, Auth::userId(), $id]);
        } else {
            $pdo->prepare('UPDATE exam_results_release SET status = ? WHERE id = ?')->execute([$status, $id]);
        }

        Logger::audit($pdo, Auth::userId(), 'EXAM_STATUS_UPDATED', "{$exam['exam_name']} -> {$status}");
        Response::json(['success' => true, 'status' => $status]);
    }

    public function importMarksCsv(Request $req): void
    {
        $file = $req->file('file');
        if (!$file || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            Response::error('Please upload a CSV file.', 422);
        }
        $handle = fopen($file['tmp_name'], 'r');
        $header = $handle ? fgetcsv($handle) : false;
        if (!$header) {
            Response::error('CSV is empty.', 422);
        }
        $idx = array_flip(array_map(fn($h) => strtolower(trim((string) $h)), $header));
        foreach (['zprn', 'subjectcode', 'semester', 'insem', 'endsem', 'practical'] as $col) {
            if (!isset($idx[$col])) {
                fclose($handle);
                Response::error("Missing column: {$col}", 422);
            }
        }

        $pdo = Database::getConnection();
        $stuStmt = $pdo->prepare('SELECT id, year FROM students WHERE zprn = ?');
        $subStmt = $pdo->prepare('SELECT * FROM subjects WHERE code = ?');
        $exStmt  = $pdo->prepare('SELECT id FROM exam_results_release WHERE year = ? AND semester = ? LIMIT 1');
        $upStmt  = $pdo->prepare(
            'INSERT INTO semester_marks (student_id, subject_id, exam_id, semester, in_sem, end_sem, practical, total_marks, max_marks, grade, grade_points, passed)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
             ON DUPLICATE KEY UPDATE in_sem=VALUES(in_sem), end_sem=VALUES(end_sem), practical=VALUES(practical),
               total_marks=VALUES(total_marks), max_marks=VALUES(max_marks), grade=VALUES(grade), grade_points=VALUES(grade_points), passed=VALUES(passed)'
        );

        $affectedStudents = [];
        $imported = 0;
        $pdo->beginTransaction();
        try {
            while (($row = fgetcsv($handle)) !== false) {
                $zprn = trim((string) ($row[$idx['zprn']] ?? ''));
                $code = trim((string) ($row[$idx['subjectcode']] ?? ''));
                $sem  = (int) ($row[$idx['semester']] ?? 5);
                $inS  = (int) ($row[$idx['insem']] ?? 0);
                $endS = (int) ($row[$idx['endsem']] ?? 0);
                $prac = (int) ($row[$idx['practical']] ?? 0);

                $stuStmt->execute([$zprn]);
                $stu = $stuStmt->fetch();
                $subStmt->execute([$code]);
                $sub = $subStmt->fetch();
                if (!$stu || !$sub) {
                    continue;
                }

                $exStmt->execute([$stu['year'], $sem]);
                $examId = $exStmt->fetchColumn() ?: null;
                [$total, $maxT, $grade, $gp, $passed] = SppuGrading::computeSubjectGrade(
                    $inS, $endS, $prac, (int) $sub['max_in_sem'], (int) $sub['max_end_sem'], (int) $sub['max_practical']
                );
                $upStmt->execute([(int) $stu['id'], (int) $sub['id'], $examId, $sem, $inS, $endS, $prac, $total, $maxT, $grade, $gp, $passed]);
                $affectedStudents[(int) $stu['id']] = true;
                $imported++;
            }
            foreach (array_keys($affectedStudents) as $sid) {
                SppuGrading::recalculateStudentAverages($pdo, $sid);
            }
            $pdo->commit();
        } catch (\Throwable $e) {
            $pdo->rollBack();
            fclose($handle);
            throw $e;
        }
        fclose($handle);
        Logger::audit($pdo, Auth::userId(), 'MARKS_BULK_IMPORT', "Imported {$imported} mark records");
        Response::json(['success' => true, 'imported' => $imported]);
    }

    public function auditLogs(Request $req): void
    {
        $pdo = Database::getConnection();
        $sql = 'SELECT al.*, u.full_name, u.identifier, u.role
                FROM audit_logs al
                LEFT JOIN users u ON al.user_id = u.id
                WHERE 1=1';
        $bind = [];
        if ($req->query('action')) {
            $sql .= ' AND al.action LIKE ?';
            $bind[] = '%' . $req->query('action') . '%';
        }
        if ($req->query('role')) {
            $sql .= ' AND u.role = ?';
            $bind[] = $req->query('role');
        }
        $sql .= ' ORDER BY al.created_at DESC LIMIT 100';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($bind);
        Response::json($stmt->fetchAll());
    }

    public function exportAuditLogs(Request $req): void
    {
        $pdo = Database::getConnection();
        $rows = $pdo->query(
            'SELECT al.created_at, COALESCE(u.identifier, "SYSTEM"), COALESCE(u.role, "SYSTEM"), al.action, al.detail, al.ip, al.status
             FROM audit_logs al LEFT JOIN users u ON al.user_id = u.id
             ORDER BY al.created_at DESC LIMIT 1000'
        )->fetchAll(PDO::FETCH_NUM);

        Logger::audit($pdo, Auth::userId(), 'AUDIT_LOGS_EXPORTED', 'HOD exported audit logs CSV');
        Response::csv('epap_audit_logs_' . date('Ymd') . '.csv', ['Timestamp', 'Actor ID', 'Role', 'Action', 'Detail', 'IP', 'Status'], $rows);
    }
}
