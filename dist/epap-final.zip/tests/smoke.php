<?php
/**
 * EPAP End-to-End Automated Smoke & Security Test Suite
 * Usage: php tests/smoke.php http://localhost:3000
 */
declare(strict_types=1);

$base = rtrim($argv[1] ?? 'http://localhost:3000', '/');
$passed = 0;
$failed = 0;

function assertTrue(bool $cond, string $label): void
{
    global $passed, $failed;
    if ($cond) {
        $passed++;
        echo "[PASS] {$label}\n";
    } else {
        $failed++;
        echo "[FAIL] {$label}\n";
    }
}

function httpReq(string $method, string $url, ?array $json = null, ?string $cookieFile = null, ?string $csrf = null, ?array $multipart = null): array
{
    $ch = curl_init($url);
    $headers = [];
    if ($csrf !== null) {
        $headers[] = 'X-CSRF-Token: ' . $csrf;
    }
    if ($json !== null) {
        $headers[] = 'Content-Type: application/json';
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($json));
    } elseif ($multipart !== null) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, $multipart);
    }
    curl_setopt_array($ch, [
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_TIMEOUT => 10,
    ]);
    if ($cookieFile) {
        curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
    }
    $body = curl_exec($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return [$code, json_decode((string) $body, true) ?? $body];
}

function loginAs(string $base, string $id, string $pw, string $role): array
{
    $cookie = tempnam(sys_get_temp_dir(), 'epap_ck_');
    [$c0, $d0] = httpReq('GET', "{$base}/api/auth/csrf", null, $cookie);
    $csrf = $d0['csrf_token'] ?? '';
    [$c1, $d1] = httpReq('POST', "{$base}/api/auth/login", ['identifier' => $id, 'password' => $pw, 'role' => $role], $cookie, $csrf);
    assertTrue($c1 === 200 && !empty($d1['devOtp']), "Login + OTP generated for {$id}");
    [$c2, $d2] = httpReq('POST', "{$base}/api/auth/verify-otp", ['otp' => $d1['devOtp']], $cookie, $csrf);
    assertTrue($c2 === 200 && ($d2['success'] ?? false) === true, "OTP verified for {$id}");
    [$c3, $d3] = httpReq('GET', "{$base}/api/auth/me", null, $cookie);
    return [$cookie, $d3['csrf_token'] ?? $csrf];
}

// 1. Health & Security Blocks
[$hc, $hd] = httpReq('GET', "{$base}/api/health");
assertTrue($hc === 200 && ($hd['status'] ?? '') === 'ok', 'Health endpoint returns 200 ok');

[$bc1] = httpReq('GET', "{$base}/.env");
[$bc2] = httpReq('GET', "{$base}/app/bootstrap.php");
[$bc3] = httpReq('GET', "{$base}/storage/logs/app.log");
assertTrue($bc1 === 403 && $bc2 === 403 && $bc3 === 403, 'Sensitive paths (.env, app/, storage/) blocked with 403');

// 2. Unauthenticated 401 & CSRF Rejection
[$uc] = httpReq('GET', "{$base}/api/student/profile");
assertTrue($uc === 401, 'Unauthenticated /api/student/profile returns 401');

[$cc] = httpReq('POST', "{$base}/api/auth/login", ['identifier' => 'x', 'password' => 'y', 'role' => 'student']);
assertTrue($cc === 403, 'POST without CSRF token rejected with 403');

// 3. Student Flow (TE-IT Div A)
[$stuCookie, $stuCsrf] = loginAs($base, 'ZCOER-IT-2023-042', 'ZCOER-IT-2023-042', 'student');
[$sc1, $sd1] = httpReq('GET', "{$base}/api/student/stats", null, $stuCookie);
assertTrue($sc1 === 200 && isset($sd1['sgpa']), 'Student stats returns real SGPA');

[$sc2, $acts] = httpReq('GET', "{$base}/api/student/activities", null, $stuCookie);
assertTrue($sc2 === 200 && is_array($acts) && count($acts) > 0, 'Student sees division activities');

// Role isolation: student cannot access faculty/admin
[$rc1] = httpReq('GET', "{$base}/api/faculty/stats", null, $stuCookie);
[$rc2] = httpReq('GET', "{$base}/api/admin/stats", null, $stuCookie);
assertTrue($rc1 === 403 && $rc2 === 403, 'Student blocked from faculty/admin endpoints (403)');

// Reject .php file upload
$badFile = tempnam(sys_get_temp_dir(), 'bad_') . '.php';
file_put_contents($badFile, '<?php echo 1; ?>');
[$upBad] = httpReq('POST', "{$base}/api/student/submit", null, $stuCookie, $stuCsrf, [
    'activity_id' => $acts[0]['id'],
    'file' => new CURLFile($badFile, 'application/x-php', 'evil.php'),
]);
@unlink($badFile);
assertTrue($upBad === 422, 'Upload rejects .php file with 422');

// Valid .txt upload
$goodFile = tempnam(sys_get_temp_dir(), 'ok_') . '.txt';
file_put_contents($goodFile, 'PL/SQL Assignment Solution');
[$upOk, $upData] = httpReq('POST', "{$base}/api/student/submit", null, $stuCookie, $stuCsrf, [
    'activity_id' => $acts[0]['id'],
    'file' => new CURLFile($goodFile, 'text/plain', 'solution.txt'),
]);
@unlink($goodFile);
assertTrue($upOk === 200 && ($upData['success'] ?? false) === true, 'Valid .txt upload succeeds');

// Analytics & Practice
[$anC, $anD] = httpReq('GET', "{$base}/api/student/analytics", null, $stuCookie);
assertTrue($anC === 200 && ($anD['prediction']['enough_data'] ?? false) === true, 'Student analytics computes explainable prediction');

[$prC, $prD] = httpReq('GET', "{$base}/api/practice/problems?track=dsa", null, $stuCookie);
assertTrue($prC === 200 && count($prD['problems'] ?? []) >= 10, 'Practice problems loaded from DB');

// 4. Student in SE-IT Div B cannot see unpublished Sem 3 results
[$stuBCookie] = loginAs($base, 'ZCOER-IT-2024-011', 'ZCOER-IT-2024-011', 'student');
[$resBC, $resBD] = httpReq('GET', "{$base}/api/student/results", null, $stuBCookie);
assertTrue($resBC === 200 && count($resBD) === 0, 'Unpublished exam results hidden from SE-IT student');

// 5. Faculty Flow + Cross-faculty grade isolation
[$facCookie, $facCsrf] = loginAs($base, 'ZCOER-FAC-IT-105', 'zeal_faculty_pass', 'faculty');
[$fgC] = httpReq('POST', "{$base}/api/faculty/grade", ['submission_id' => 1, 'marks' => 20, 'feedback' => 'Test'], $facCookie, $facCsrf);
assertTrue($fgC === 403, 'Faculty cannot grade another faculty submission (403)');

// 6. Admin Flow + CSV Import
[$admCookie, $admCsrf] = loginAs($base, 'ZCOER-HOD-IT', 'zeal_hod_secure', 'admin');
$csvPath = tempnam(sys_get_temp_dir(), 'csv_') . '.csv';
file_put_contents($csvPath, "ZPRN,FullName,Email,Year,Division,RollNo\nZCOER-IT-2023-042,Dup User,dup@zealstudy.in,TE-IT,A,42\n,Bad Row,not-an-email,TE-IT,A,99\n");
[$impC, $impD] = httpReq('POST', "{$base}/api/admin/students/import", null, $admCookie, $admCsrf, [
    'file' => new CURLFile($csvPath, 'text/csv', 'students.csv'),
]);
@unlink($csvPath);
assertTrue($impC === 200 && ($impD['skipped'] ?? 0) === 1 && ($impD['errors'] ?? 0) === 1, 'Bulk CSV import reports skipped duplicates and row errors');

// 7. Login Throttling (5 failures -> 429)
$thCookie = tempnam(sys_get_temp_dir(), 'th_');
[, $thCsrfRes] = httpReq('GET', "{$base}/api/auth/csrf", null, $thCookie);
$thCsrf = $thCsrfRes['csrf_token'] ?? '';
for ($i = 0; $i < 5; $i++) {
    httpReq('POST', "{$base}/api/auth/login", ['identifier' => 'THROTTLE-TEST', 'password' => 'wrong', 'role' => 'student'], $thCookie, $thCsrf);
}
[$thC] = httpReq('POST', "{$base}/api/auth/login", ['identifier' => 'THROTTLE-TEST', 'password' => 'wrong', 'role' => 'student'], $thCookie, $thCsrf);
assertTrue($thC === 429, 'Login throttling returns 429 after 5 failed attempts');

echo "\n=== Smoke Test Summary: {$passed} passed, {$failed} failed ===\n";
exit($failed > 0 ? 1 : 0);
