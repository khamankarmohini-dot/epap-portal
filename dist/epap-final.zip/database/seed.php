<?php
/**
 * EPAP - Idempotent Database Seeder
 * Run via CLI: php database/seed.php
 */
declare(strict_types=1);

require_once __DIR__ . '/../app/bootstrap.php';

use App\Core\Database;

function sppuGrade(int $obtained, int $maxTotal, int $endSem, int $maxEndSem): array
{
    $pct = $maxTotal > 0 ? ($obtained / $maxTotal) * 100.0 : 0.0;
    if ($maxEndSem > 0 && $endSem < (int) ceil($maxEndSem * 0.40)) {
        return ['F', 0.00, 0];
    }
    if ($pct >= 85) return ['O', 10.00, 1];
    if ($pct >= 75) return ['A+', 9.00, 1];
    if ($pct >= 65) return ['A', 8.00, 1];
    if ($pct >= 55) return ['B+', 7.00, 1];
    if ($pct >= 50) return ['B', 6.00, 1];
    if ($pct >= 45) return ['C', 5.00, 1];
    if ($pct >= 40) return ['P', 4.00, 1];
    return ['F', 0.00, 0];
}

function runSeed(PDO $pdo): void
{
    // 1. Users
    $users = [
        ['ZCOER-IT-2023-042', 'ZCOER-IT-2023-042', 'student', 'Rohan K. Sharma',      'rohan.sharma2023@zealstudy.in', 0],
        ['ZCOER-IT-2023-058', 'ZCOER-IT-2023-058', 'student', 'Priya A. Verma',       'priya.verma2023@zealstudy.in', 0],
        ['ZCOER-IT-2023-019', 'ZCOER-IT-2023-019', 'student', 'Aditya M. Joshi',      'aditya.joshi2023@zealstudy.in', 0],
        ['ZCOER-IT-2024-011', 'ZCOER-IT-2024-011', 'student', 'Sneha R. Deshmukh',    'sneha.deshmukh2024@zealstudy.in', 0],
        ['ZCOER-FAC-IT-102',  'zeal_faculty_pass', 'faculty', 'Prof. S. N. Patil',    's.patil@zealstudy.in', 0],
        ['ZCOER-FAC-IT-105',  'zeal_faculty_pass', 'faculty', 'Prof. K. V. Joshi',    'k.joshi@zealstudy.in', 0],
        ['ZCOER-FAC-IT-108',  'zeal_faculty_pass', 'faculty', 'Prof. M. B. Shinde',   'm.shinde@zealstudy.in', 0],
        ['ZCOER-HOD-IT',      'zeal_hod_secure',   'admin',   'Prof. Balaji Chaugule','hod.it@zealstudy.in', 0],
    ];

    $stmtUser = $pdo->prepare(
        'INSERT IGNORE INTO users (identifier, password_hash, role, full_name, email, must_change_password) VALUES (?,?,?,?,?,?)'
    );
    foreach ($users as [$ident, $pw, $role, $name, $email, $mustChange]) {
        $stmtUser->execute([$ident, password_hash($pw, PASSWORD_BCRYPT), $role, $name, $email, $mustChange]);
    }

    $getUserId = function (string $ident) use ($pdo): int {
        $s = $pdo->prepare('SELECT id FROM users WHERE identifier = ?');
        $s->execute([$ident]);
        return (int) $s->fetchColumn();
    };

    // 2. Students
    $students = [
        ['ZCOER-IT-2023-042', 'T23104921', 42, 'A', 'TE-IT', 5, 8.64, 8.92],
        ['ZCOER-IT-2023-058', 'T23104958', 58, 'A', 'TE-IT', 5, 7.80, 7.95],
        ['ZCOER-IT-2023-019', 'T23104919', 19, 'A', 'TE-IT', 5, 8.10, 8.20],
        ['ZCOER-IT-2024-011', 'S24103011', 11, 'B', 'SE-IT', 3, 7.90, 7.90],
    ];
    $stmtStu = $pdo->prepare(
        'INSERT IGNORE INTO students (user_id, zprn, seat_number, roll_no, division, year, semester, cgpa, current_sgpa)
         VALUES (?,?,?,?,?,?,?,?,?)'
    );
    foreach ($students as [$zprn, $seat, $roll, $div, $year, $sem, $cgpa, $sgpa]) {
        $stmtStu->execute([$getUserId($zprn), $zprn, $seat, $roll, $div, $year, $sem, $cgpa, $sgpa]);
    }

    // 3. Faculty
    $faculty = [
        ['ZCOER-FAC-IT-102', 'Assistant Professor', 'Information Technology'],
        ['ZCOER-FAC-IT-105', 'Assistant Professor', 'Information Technology'],
        ['ZCOER-FAC-IT-108', 'Associate Professor', 'Information Technology'],
    ];
    $stmtFac = $pdo->prepare(
        'INSERT IGNORE INTO faculty (user_id, faculty_id, designation, department) VALUES (?,?,?,?)'
    );
    foreach ($faculty as [$fid, $desig, $dept]) {
        $stmtFac->execute([$getUserId($fid), $fid, $desig, $dept]);
    }

    // 4. Subjects (Sem 1-5)
    $subjects = [
        ['107001', 'Engineering Mathematics I',              1, 4, 30, 70, 0],
        ['110005', 'Programming & Problem Solving',          1, 4, 30, 70, 50],
        ['107008', 'Engineering Mathematics II',             2, 4, 30, 70, 0],
        ['104010', 'Basic Electronics Engineering',          2, 4, 30, 70, 50],
        ['214441', 'Discrete Mathematics',                   3, 4, 30, 70, 0],
        ['214442', 'Data Structures & Algorithms',           3, 4, 30, 70, 50],
        ['214451', 'Processor Architecture',                 4, 4, 30, 70, 50],
        ['214452', 'Operating Systems',                      4, 4, 30, 70, 50],
        ['314441', 'Database Management Systems (DBMS)',     5, 4, 30, 70, 50],
        ['314442', 'Computer Networks & Security (CNS)',     5, 4, 30, 70, 50],
        ['314443', 'Web Technology (WT)',                    5, 4, 30, 70, 50],
        ['314444', 'Theory of Computation (TOC)',            5, 4, 30, 70, 0],
        ['314445', 'Software Engineering & Project Mgmt',    5, 3, 30, 70, 0],
        ['314447', 'OOP & Java Lab',                         3, 3, 30, 70, 50],
    ];
    $stmtSub = $pdo->prepare(
        'INSERT IGNORE INTO subjects (code, name, semester, credits, max_in_sem, max_end_sem, max_practical)
         VALUES (?,?,?,?,?,?,?)'
    );
    foreach ($subjects as $s) {
        $stmtSub->execute($s);
    }

    $getFacId = function (string $fid) use ($pdo): int {
        $s = $pdo->prepare('SELECT id FROM faculty WHERE faculty_id = ?');
        $s->execute([$fid]);
        return (int) $s->fetchColumn();
    };
    $getSubId = function (string $code) use ($pdo): int {
        $s = $pdo->prepare('SELECT id FROM subjects WHERE code = ?');
        $s->execute([$code]);
        return (int) $s->fetchColumn();
    };
    $getStuId = function (string $zprn) use ($pdo): int {
        $s = $pdo->prepare('SELECT id FROM students WHERE zprn = ?');
        $s->execute([$zprn]);
        return (int) $s->fetchColumn();
    };

    $fac1 = $getFacId('ZCOER-FAC-IT-102');
    $fac2 = $getFacId('ZCOER-FAC-IT-105');
    $fac3 = $getFacId('ZCOER-FAC-IT-108');
    $hodUserId = $getUserId('ZCOER-HOD-IT');

    // 5. Faculty Allocations
    $allocations = [
        [$fac1, $getSubId('314441'), 'TE-IT', 'A', '2025-26'],
        [$fac1, $getSubId('314442'), 'TE-IT', 'A', '2025-26'],
        [$fac1, $getSubId('314447'), 'SE-IT', 'B', '2025-26'],
        [$fac2, $getSubId('314443'), 'TE-IT', 'A', '2025-26'],
        [$fac2, $getSubId('314445'), 'TE-IT', 'A', '2025-26'],
        [$fac3, $getSubId('314444'), 'TE-IT', 'A', '2025-26'],
    ];
    $stmtAlloc = $pdo->prepare(
        'INSERT IGNORE INTO faculty_allocations (faculty_id, subject_id, year, division, academic_year, status)
         VALUES (?,?,?,?,?,\'active\')'
    );
    foreach ($allocations as $a) {
        $stmtAlloc->execute($a);
    }

    // 6. Activities (mix of future & past deadlines relative to 2026-11-25)
    $now = time();
    $dtFuture1 = date('Y-m-d H:i:s', $now + 3 * 86400);
    $dtFuture2 = date('Y-m-d H:i:s', $now + 5 * 86400);
    $dtFuture3 = date('Y-m-d H:i:s', $now + 10 * 86400);
    $dtPast1   = date('Y-m-d H:i:s', $now - 3 * 86400);
    $dtPast2   = date('Y-m-d H:i:s', $now - 7 * 86400);

    $activities = [
        [$fac1, $getSubId('314441'), 'Lab Assignment 4: PL/SQL Triggers & Procedures', 'Lab Practical Journal', 'Write PL/SQL trigger handling before/after states and stored procedures with cursors.', 25, $dtFuture1, 'TE-IT', 'A'],
        [$fac2, $getSubId('314443'), 'Milestone 2: Responsive PHP + MySQL Portal', 'Mini-Project Milestone', 'Build a fully responsive PHP app with MySQL PDO backend demonstrating CRUD operations.', 50, $dtFuture2, 'TE-IT', 'A'],
        [$fac1, $getSubId('314442'), 'Socket Programming in C: TCP Client-Server', 'Lab Practical Journal', 'Implement TCP client-server communication using socket programming in C.', 25, $dtPast1, 'TE-IT', 'A'],
        [$fac3, $getSubId('314444'), 'Turing Machine Assignment', 'Theory Assignment', 'Design and simulate a Turing Machine with transition table and state minimization.', 25, $dtPast2, 'TE-IT', 'A'],
        [$fac2, $getSubId('314445'), 'Agile Sprint Backlog & Jira Case Study', 'Research Case Study', 'Create sprint backlog, user stories and velocity metrics using Agile methodology.', 50, $dtPast2, 'TE-IT', 'A'],
        [$fac1, $getSubId('314447'), 'Assignment 2: Polymorphism & Abstract Classes', 'Lab Practical Journal', 'Implement Shape abstract class with Circle & Rectangle subclasses.', 25, $dtFuture3, 'SE-IT', 'B'],
    ];
    $stmtActCheck = $pdo->prepare('SELECT id FROM activities WHERE title = ? AND faculty_id = ?');
    $stmtActIns = $pdo->prepare(
        'INSERT INTO activities (faculty_id, subject_id, title, activity_type, description, max_marks, deadline, year, division)
         VALUES (?,?,?,?,?,?,?,?,?)'
    );
    $actIds = [];
    foreach ($activities as $a) {
        $stmtActCheck->execute([$a[2], $a[0]]);
        $existingId = $stmtActCheck->fetchColumn();
        if ($existingId) {
            $actIds[] = (int) $existingId;
        } else {
            $stmtActIns->execute($a);
            $actIds[] = (int) $pdo->lastInsertId();
        }
    }

    // 7. Submissions
    $stu1 = $getStuId('ZCOER-IT-2023-042');
    $stu2 = $getStuId('ZCOER-IT-2023-058');
    $stu3 = $getStuId('ZCOER-IT-2023-019');

    $submissions = [
        [$actIds[2], $stu1, 'tcp_client_server.zip', 'tcp_client_server.zip', null, null, 'submitted', 0, null],
        [$actIds[3], $stu1, 'turing_machine.pdf', 'turing_machine.pdf', 24, 'Excellent transition table and state minimization technique demonstrated.', 'graded', 0, date('Y-m-d H:i:s', $now - 86400)],
        [$actIds[4], $stu1, 'agile_sprint.zip', 'agile_sprint.zip', 46, 'User stories and velocity metrics are clearly defined. Keep it up!', 'graded', 0, date('Y-m-d H:i:s', $now - 3 * 86400)],
        [$actIds[0], $stu2, 'plsql_triggers.zip', 'plsql_triggers.zip', null, null, 'submitted', 0, null],
        [$actIds[0], $stu3, 'lab3_indexing.zip', 'lab3_indexing.zip', null, null, 'submitted', 1, null],
    ];
    $stmtSubm = $pdo->prepare(
        'INSERT IGNORE INTO submissions (activity_id, student_id, file_name, original_name, marks, feedback, status, is_late, graded_at)
         VALUES (?,?,?,?,?,?,?,?,?)'
    );
    foreach ($submissions as $sm) {
        $stmtSubm->execute($sm);
    }

    // 8. Exam Result Releases (mixed states)
    $exams = [
        ['TE-IT Semester I Examination',  'TE-IT', 1, 'combined', '2023-24', 'Dec 2023', 'published', date('Y-m-d H:i:s', $now - 365 * 86400), $hodUserId],
        ['TE-IT Semester II Examination', 'TE-IT', 2, 'combined', '2023-24', 'May 2024', 'published', date('Y-m-d H:i:s', $now - 240 * 86400), $hodUserId],
        ['TE-IT Semester III Examination','TE-IT', 3, 'combined', '2024-25', 'Dec 2024', 'published', date('Y-m-d H:i:s', $now - 150 * 86400), $hodUserId],
        ['TE-IT Semester IV Examination', 'TE-IT', 4, 'combined', '2024-25', 'May 2025', 'published', date('Y-m-d H:i:s', $now - 60 * 86400),  $hodUserId],
        ['TE-IT Semester V Examination',  'TE-IT', 5, 'combined', '2025-26', 'Oct 2026', 'published', date('Y-m-d H:i:s', $now - 5 * 86400),   $hodUserId],
        ['SE-IT Semester III In-Sem Exam','SE-IT', 3, 'in_sem',   '2025-26', 'Sept 2026','under_moderation', null, null],
        ['TE-IT Semester VI Prelim',      'TE-IT', 6, 'in_sem',   '2025-26', 'Nov 2026', 'draft', null, null],
    ];
    $stmtExam = $pdo->prepare(
        'INSERT IGNORE INTO exam_results_release (exam_name, year, semester, exam_type, academic_year, conducted_label, status, published_at, published_by)
         VALUES (?,?,?,?,?,?,?,?,?)'
    );
    foreach ($exams as $ex) {
        $stmtExam->execute($ex);
    }

    $getExamId = function (string $year, int $sem, string $type) use ($pdo): ?int {
        $s = $pdo->prepare('SELECT id FROM exam_results_release WHERE year=? AND semester=? AND exam_type=? LIMIT 1');
        $s->execute([$year, $sem, $type]);
        $v = $s->fetchColumn();
        return $v ? (int) $v : null;
    };

    // 9. Semester Marks (5 semesters for Rohan + Sem 5 for Priya & Aditya + Sem 3 unpublished for Sneha)
    $marksEntries = [
        // Rohan Sem 1-4
        [$stu1, '107001', 1, 24, 58, 0, 8.12, 'TE-IT'],
        [$stu1, '110005', 1, 26, 60, 42, 8.12, 'TE-IT'],
        [$stu1, '107008', 2, 25, 62, 0, 8.45, 'TE-IT'],
        [$stu1, '104010', 2, 26, 61, 44, 8.45, 'TE-IT'],
        [$stu1, '214441', 3, 24, 59, 0, 8.28, 'TE-IT'],
        [$stu1, '214442', 3, 26, 62, 44, 8.28, 'TE-IT'],
        [$stu1, '214451', 4, 27, 63, 45, 8.76, 'TE-IT'],
        [$stu1, '214452', 4, 27, 64, 46, 8.76, 'TE-IT'],
        // Rohan Sem 5
        [$stu1, '314441', 5, 27, 59, 45, 8.92, 'TE-IT'],
        [$stu1, '314442', 5, 24, 54, 42, 8.92, 'TE-IT'],
        [$stu1, '314443', 5, 29, 64, 48, 8.92, 'TE-IT'],
        [$stu1, '314444', 5, 22, 48, 0,  8.92, 'TE-IT'],
        [$stu1, '314445', 5, 26, 56, 0,  8.92, 'TE-IT'],
        // Priya Sem 5
        [$stu2, '314441', 5, 21, 49, 38, 7.95, 'TE-IT'],
        [$stu2, '314442', 5, 20, 48, 36, 7.95, 'TE-IT'],
        [$stu2, '314443', 5, 24, 55, 41, 7.95, 'TE-IT'],
        [$stu2, '314444', 5, 19, 44, 0,  7.95, 'TE-IT'],
        [$stu2, '314445', 5, 22, 50, 0,  7.95, 'TE-IT'],
        // Aditya Sem 5
        [$stu3, '314441', 5, 23, 52, 40, 8.20, 'TE-IT'],
        [$stu3, '314442', 5, 22, 50, 39, 8.20, 'TE-IT'],
        [$stu3, '314443', 5, 25, 58, 43, 8.20, 'TE-IT'],
        [$stu3, '314444', 5, 20, 46, 0,  8.20, 'TE-IT'],
        [$stu3, '314445', 5, 23, 52, 0,  8.20, 'TE-IT'],
        // Sneha Sem 3 (under_moderation — must NOT be visible to student!)
        [$getStuId('ZCOER-IT-2024-011'), '214441', 3, 22, 0, 0, 7.90, 'SE-IT'],
        [$getStuId('ZCOER-IT-2024-011'), '214442', 3, 24, 0, 0, 7.90, 'SE-IT'],
    ];

    $stmtMarks = $pdo->prepare(
        'INSERT IGNORE INTO semester_marks
         (student_id, subject_id, exam_id, semester, in_sem, end_sem, practical, total_marks, max_marks, grade, grade_points, passed, sgpa)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)'
    );
    $subInfoStmt = $pdo->prepare('SELECT id, max_in_sem, max_end_sem, max_practical FROM subjects WHERE code = ?');
    foreach ($marksEntries as [$stId, $subCode, $sem, $inS, $endS, $prac, $sgpaVal, $yr]) {
        $subInfoStmt->execute([$subCode]);
        $sub = $subInfoStmt->fetch();
        if (!$sub) continue;
        $maxTotal = (int) $sub['max_in_sem'] + (int) $sub['max_end_sem'] + (int) $sub['max_practical'];
        $total = $inS + $endS + $prac;
        [$grade, $gp, $passed] = sppuGrade($total, $maxTotal, $endS, (int) $sub['max_end_sem']);
        $examId = $getExamId($yr, $sem, $yr === 'SE-IT' ? 'in_sem' : 'combined');
        $stmtMarks->execute([$stId, (int) $sub['id'], $examId, $sem, $inS, $endS, $prac, $total, $maxTotal, $grade, $gp, $passed, $sgpaVal]);
    }

    // 10. Practice Problems (16 real problems across DSA, OOP, DBMS)
    $problems = [
        [1, 'dsa', 'Two Sum', 'Easy', 'Arrays & Hashing',
         'Given an array of integers <code>nums</code> and an integer <code>target</code>, return indices of the two numbers such that they add up to target.',
         ['2 <= nums.length <= 10^4', '-10^9 <= nums[i] <= 10^9', 'Only one valid answer exists.'],
         [['input' => 'nums = [2,7,11,15], target = 9', 'output' => '[0,1]', 'explanation' => 'nums[0] + nums[1] == 9']],
         ['python' => "def twoSum(nums, target):\n    seen = {}\n    for i, n in enumerate(nums):\n        if target - n in seen:\n            return [seen[target - n], i]\n        seen[n] = i\n",
          'java' => "class Solution {\n    public int[] twoSum(int[] nums, int target) {\n        return new int[]{};\n    }\n}",
          'cpp' => "#include <vector>\nusing namespace std;\nclass Solution {\npublic:\n    vector<int> twoSum(vector<int>& nums, int target) {\n        return {};\n    }\n};",
          'c' => "int* twoSum(int* nums, int numsSize, int target, int* returnSize) {\n    *returnSize = 2;\n    return NULL;\n}"],
         [['2 7 11 15\n9', '0 1', 1], ['3 2 4\n6', '1 2', 0]]
        ],
        [2, 'dsa', 'Reverse Linked List', 'Easy', 'Linked List',
         'Given the <code>head</code> of a singly linked list, reverse the list, and return the reversed list.',
         ['0 <= nodes <= 5000', '-5000 <= Node.val <= 5000'],
         [['input' => '1 2 3 4 5', 'output' => '5 4 3 2 1', 'explanation' => 'List is reversed.']],
         ['python' => "def reverseList(arr):\n    return arr[::-1]\n", 'java' => "// Reverse linked list", 'cpp' => "// Reverse linked list", 'c' => "// Reverse linked list"],
         [['1 2 3 4 5', '5 4 3 2 1', 1], ['10 20', '20 10', 0]]
        ],
        [3, 'dsa', 'Valid Parentheses', 'Easy', 'Stack & Queue',
         'Given a string <code>s</code> containing just the characters <code>( ) { } [ ]</code>, determine if the input string is valid.',
         ['1 <= s.length <= 10^4'],
         [['input' => '()[]{}', 'output' => 'true', 'explanation' => 'All brackets match in order.']],
         ['python' => "def isValid(s: str) -> bool:\n    pass\n", 'java' => "class Solution { public boolean isValid(String s) { return false; } }", 'cpp' => "class Solution { public: bool isValid(string s) { return false; } };", 'c' => "int isValid(char* s) { return 0; }"],
         [['()[]{}', 'true', 1], ['([)]', 'false', 0]]
        ],
        [4, 'dsa', 'Binary Search', 'Easy', 'Searching',
         'Given a sorted array of integers <code>nums</code> and a <code>target</code>, return its index or -1 in O(log n) time.',
         ['1 <= nums.length <= 10^4', 'All elements are unique and sorted ascending.'],
         [['input' => 'nums = [-1,0,3,5,9,12], target = 9', 'output' => '4', 'explanation' => '9 is at index 4.']],
         ['python' => "def search(nums, target):\n    return -1\n", 'java' => "class Solution { public int search(int[] nums, int target) { return -1; } }", 'cpp' => "class Solution { public: int search(vector<int>& nums, int target) { return -1; } };", 'c' => "int search(int* nums, int n, int target) { return -1; }"],
         [['-1 0 3 5 9 12\n9', '4', 1], ['-1 0 3 5 9 12\n2', '-1', 0]]
        ],
        [5, 'dsa', 'Maximum Subarray (Kadane)', 'Medium', 'Dynamic Programming',
         'Find the contiguous subarray with the largest sum and return its sum.',
         ['1 <= nums.length <= 10^5'],
         [['input' => '-2 1 -3 4 -1 2 1 -5 4', 'output' => '6', 'explanation' => 'Subarray [4,-1,2,1] has sum 6.']],
         ['python' => "def maxSubArray(nums):\n    pass\n", 'java' => "class Solution { public int maxSubArray(int[] nums) { return 0; } }", 'cpp' => "class Solution { public: int maxSubArray(vector<int>& nums) { return 0; } };", 'c' => "int maxSubArray(int* nums, int n) { return 0; }"],
         [['-2 1 -3 4 -1 2 1 -5 4', '6', 1], ['1', '1', 0]]
        ],
        [6, 'dsa', 'Merge Intervals', 'Medium', 'Sorting & Intervals',
         'Given an array of intervals, merge all overlapping intervals and return the non-overlapping intervals.',
         ['1 <= intervals.length <= 10^4'],
         [['input' => '[[1,3],[2,6],[8,10],[15,18]]', 'output' => '[[1,6],[8,10],[15,18]]', 'explanation' => '[1,3] and [2,6] overlap.']],
         ['python' => "def merge(intervals):\n    return []\n", 'java' => "// Merge intervals", 'cpp' => "// Merge intervals", 'c' => "// Merge intervals"],
         [['1,3 2,6 8,10 15,18', '1,6 8,10 15,18', 1]]
        ],
        [7, 'dsa', 'Binary Tree Level Order Traversal', 'Medium', 'Trees & BFS',
         'Given the root of a binary tree, return the level order traversal of its nodes values.',
         ['0 <= nodes <= 2000'],
         [['input' => 'root = [3,9,20,null,null,15,7]', 'output' => '[[3],[9,20],[15,7]]', 'explanation' => 'Level by level BFS.']],
         ['python' => "def levelOrder(root):\n    return []\n", 'java' => "// Level order", 'cpp' => "// Level order", 'c' => "// Level order"],
         [['3 9 20 null null 15 7', '3 | 9 20 | 15 7', 1]]
        ],
        [8, 'dsa', 'Number of Islands', 'Medium', 'Graphs & DFS/BFS',
         'Given an m x n 2D grid of 1s (land) and 0s (water), return the number of islands.',
         ['1 <= m, n <= 300'],
         [['input' => '4x5 grid', 'output' => '1', 'explanation' => 'All 1s are connected.']],
         ['python' => "def numIslands(grid):\n    return 0\n", 'java' => "// Number of islands", 'cpp' => "// Number of islands", 'c' => "// Number of islands"],
         [['11110\n11010\n11000\n00000', '1', 1]]
        ],
        [9, 'dsa', 'Coin Change', 'Medium', 'Dynamic Programming',
         'Return the fewest number of coins needed to make up a given amount, or -1 if impossible.',
         ['1 <= coins.length <= 12', '0 <= amount <= 10^4'],
         [['input' => 'coins = [1,2,5], amount = 11', 'output' => '3', 'explanation' => '11 = 5 + 5 + 1']],
         ['python' => "def coinChange(coins, amount):\n    return -1\n", 'java' => "// Coin change", 'cpp' => "// Coin change", 'c' => "// Coin change"],
         [['1 2 5\n11', '3', 1], ['2\n3', '-1', 0]]
        ],
        [10, 'dsa', 'LRU Cache Design', 'Hard', 'Design & Hash Table',
         'Design an LRU Cache supporting O(1) get and put operations.',
         ['1 <= capacity <= 3000'],
         [['input' => 'capacity=2, put(1,1), put(2,2), get(1)', 'output' => '1', 'explanation' => 'Key 1 is cached.']],
         ['python' => "class LRUCache:\n    def __init__(self, cap): pass\n", 'java' => "class LRUCache {}", 'cpp' => "class LRUCache {};", 'c' => "// LRU Cache"],
         [['2\nput 1 1\nput 2 2\nget 1', '1', 1]]
        ],
        [11, 'oop', 'Virtual Functions & Runtime Polymorphism', 'Easy', 'Polymorphism',
         'Create an abstract base class <code>Shape</code> with a pure virtual method <code>area()</code>. Derive <code>Circle</code> and <code>Rectangle</code>.',
         ['Dimensions are positive floats.'],
         [['input' => 'Circle(5.0)', 'output' => '78.54', 'explanation' => '3.14159 * 25']],
         ['python' => "from abc import ABC, abstractmethod\nclass Shape(ABC):\n    @abstractmethod\n    def area(self): pass\n", 'java' => "abstract class Shape { abstract double area(); }", 'cpp' => "class Shape { public: virtual double area() = 0; };", 'c' => "// Function pointers"],
         [['circle 5', '78.54', 1], ['rect 4 5', '20.00', 0]]
        ],
        [12, 'oop', 'Operator Overloading (Complex Numbers)', 'Medium', 'Operator Overloading',
         'Overload + and * operators for a <code>Complex</code> number class.',
         ['Real and imaginary parts are integers.'],
         [['input' => '(3+2i) + (1+7i)', 'output' => '4+9i', 'explanation' => 'Add real and imag parts.']],
         ['python' => "class Complex:\n    def __add__(self, other): pass\n", 'java' => "// Complex add method", 'cpp' => "class Complex {};", 'c' => "// Struct Complex"],
         [['3 2 1 7', '4+9i', 1]]
        ],
        [13, 'oop', 'Generic Stack Template', 'Medium', 'Templates & Generics',
         'Implement a generic Stack supporting push, pop, peek, and isEmpty.',
         ['1 <= operations <= 1000'],
         [['input' => 'push 10, push 20, peek', 'output' => '20', 'explanation' => 'LIFO order.']],
         ['python' => "class Stack:\n    pass\n", 'java' => "class Stack<T> {}", 'cpp' => "template<typename T> class Stack {};", 'c' => "// Generic void* stack"],
         [['push 10\npush 20\npeek', '20', 1]]
        ],
        [14, 'dbms', 'Second Highest Salary', 'Medium', 'SQL Subquery',
         'Write an SQL query to find the second highest distinct salary from the <code>Employee</code> table.',
         ['Employee(id, salary)'],
         [['input' => '[100, 200, 300]', 'output' => '200', 'explanation' => 'Second highest is 200.']],
         ['python' => 'query = "SELECT MAX(salary) FROM Employee WHERE salary < (SELECT MAX(salary) FROM Employee);"' , 'java' => 'String sql = "";', 'cpp' => 'string sql = "";', 'c' => 'const char* sql = "";'],
         [['100 200 300', '200', 1]]
        ],
        [15, 'dbms', 'Department Top Three Salaries', 'Hard', 'Window Functions',
         'Find employees who earn one of the top 3 unique salaries in each department using DENSE_RANK().',
         ['Employee(id, name, salary, departmentId)'],
         [['input' => 'IT: [90k, 85k, 85k, 70k]', 'output' => 'All 4', 'explanation' => 'Three unique salaries: 90k, 85k, 70k.']],
         ['python' => 'query = "SELECT ..."' , 'java' => 'String sql = "";', 'cpp' => 'string sql = "";', 'c' => 'const char* sql = "";'],
         [['IT 90000 85000 70000', '90000 85000 70000', 1]]
        ],
        [16, 'dbms', 'Customers Who Never Order', 'Easy', 'SQL Joins',
         'Find all customers who never placed an order using LEFT JOIN or NOT EXISTS.',
         ['Customers(id, name), Orders(id, customerId)'],
         [['input' => 'Customers: Joe, Henry; Orders: Joe', 'output' => 'Henry', 'explanation' => 'Henry has no orders.']],
         ['python' => 'query = "SELECT name FROM Customers WHERE id NOT IN (SELECT customerId FROM Orders);"' , 'java' => 'String sql = "";', 'cpp' => 'string sql = "";', 'c' => 'const char* sql = "";'],
         [['Joe,Henry | Joe', 'Henry', 1]]
        ],
    ];

    $stmtProb = $pdo->prepare(
        'INSERT IGNORE INTO practice_problems
         (problem_number, subject_track, title, difficulty, topic, description, constraints_json, examples_json, starter_code_json)
         VALUES (?,?,?,?,?,?,?,?,?)'
    );
    $stmtProbId = $pdo->prepare('SELECT id FROM practice_problems WHERE subject_track = ? AND problem_number = ?');
    $stmtTcCount = $pdo->prepare('SELECT COUNT(*) FROM practice_testcases WHERE problem_id = ?');
    $stmtTcIns = $pdo->prepare('INSERT INTO practice_testcases (problem_id, input_data, expected_output, is_sample) VALUES (?,?,?,?)');

    foreach ($problems as [$num, $track, $title, $diff, $topic, $desc, $cons, $ex, $starter, $tcs]) {
        $stmtProb->execute([
            $num, $track, $title, $diff, $topic, $desc,
            json_encode($cons), json_encode($ex), json_encode($starter)
        ]);
        $stmtProbId->execute([$track, $num]);
        $pid = (int) $stmtProbId->fetchColumn();
        $stmtTcCount->execute([$pid]);
        if ((int) $stmtTcCount->fetchColumn() === 0) {
            foreach ($tcs as [$in, $out, $isSample]) {
                $stmtTcIns->execute([$pid, $in, $out, $isSample]);
            }
        }
    }

    // 11. Notifications (if none exist for Rohan)
    $rohanUid = $getUserId('ZCOER-IT-2023-042');
    $chkNotif = $pdo->prepare('SELECT COUNT(*) FROM notifications WHERE user_id = ?');
    $chkNotif->execute([$rohanUid]);
    if ((int) $chkNotif->fetchColumn() === 0) {
        $insNotif = $pdo->prepare('INSERT INTO notifications (user_id, title, message, link) VALUES (?,?,?,?)');
        $insNotif->execute([$rohanUid, 'New Activity: DBMS Lab 4', 'Prof. S. N. Patil posted Lab Assignment 4: PL/SQL Triggers & Procedures.', '/student-activities.html']);
        $insNotif->execute([$rohanUid, 'Marks Published: Sem V', 'HOD published TE-IT Semester V Examination results.', '/student-results.html']);
    }
}

if (PHP_SAPI === 'cli' && realpath($_SERVER['SCRIPT_FILENAME'] ?? '') === __FILE__) {
    $pdo = Database::getConnection();
    runSeed($pdo);
    echo "EPAP database seeded successfully.\n";
}
