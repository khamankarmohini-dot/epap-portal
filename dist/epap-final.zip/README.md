# Zeal EPAP — Examination & Predictive Analytics Portal

**Zeal College of Engineering & Research (ZCOER), Narhe, Pune — Department of Information Technology**

A full-stack **PHP 8.1+ (PDO / MySQL 8)** + Bootstrap 5 + Chart.js academic portal featuring 2-step email OTP authentication, role-based dashboards (Student, Faculty, HOD/Admin), real multipart activity submissions with server-side late detection, SPPU 10-point SGPA/CGPA calculation, explainable predictive analytics, bulk CSV enrollment, and a database-driven coding practice arena.

---

## Requirements
- **PHP 8.1+** with extensions: `pdo_mysql`, `mbstring`, `fileinfo`, `openssl`, `json` (optional `curl` for Judge0)
- **MySQL 8.0+**
- Optional: **Composer + PHPMailer** (for real SMTP delivery) and **Judge0 API** (for remote code execution; defaults to explicit Demo Mode if unconfigured)

---

## Quick Start (One-Command Setup)

```bash
php setup.php
```

This checks PHP & extensions, creates `.env` from `.env.example` if missing, initializes `epap_db` from `database/schema.sql`, seeds demo data via `database/seed.php`, and creates `storage/` directories.

### Option A: PHP Built-in Server (Recommended for Local Dev)
```bash
php -S localhost:3000 router.php
```
Open: `http://localhost:3000/login.html`

### Option B: XAMPP / Apache VirtualHost
The frontend uses root-relative `/api/...` paths. Configure an Apache `<VirtualHost>` whose `DocumentRoot` points directly to the project root (do **not** serve from a subfolder unless you set `window.EPAP_BASE_PATH` in `assets/js/api.js`):
```apache
<VirtualHost *:80>
    ServerName epap.local
    DocumentRoot "C:/path/to/epap"
    <Directory "C:/path/to/epap">
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>
```

---

## Demo Credentials

| Role | Identifier | Password |
|---|---|---|
| **Student (TE-IT Div A)** | `ZCOER-IT-2023-042` | `ZCOER-IT-2023-042` |
| **Student (SE-IT Div B)** | `ZCOER-IT-2024-011` | `ZCOER-IT-2024-011` |
| **Faculty** | `ZCOER-FAC-IT-102` | `zeal_faculty_pass` |
| **HOD / Admin** | `ZCOER-HOD-IT` | `zeal_hod_secure` |

> In `APP_ENV=local`, the 6-digit OTP is returned as `devOtp` for auto-fill and logged to `storage/mail/otp.log`. Set `APP_ENV=production` and configure `SMTP_*` in `.env` for production.

---

## Folder Structure
- `api/index.php` — API front controller
- `app/` — `bootstrap.php`, `Core/`, `Controllers/`, `Middleware/`
- `database/` — `schema.sql`, `seed.php`
- `storage/` — `uploads/`, `logs/`, `mail/` (blocked from direct web access)
- `assets/` — `css/style.css`, `js/api.js`, `js/main.js`, `js/analytics.js`, `js/code-practice.js`
- `docs/` — `AUDIT.md`, `DECISIONS.md`, `API.md`, `TESTING.md`, `FINAL_REPORT.md`
- `tests/` — `smoke.php`
