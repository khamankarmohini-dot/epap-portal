<?php
/**
 * EPAP - One-Command Setup & Installer
 * Run: php setup.php
 */
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('Forbidden: Run setup.php from the command line.');
}

echo "=== Zeal EPAP (PHP 8.1+ / MySQL 8) Setup ===\n";

// 1. Check PHP Version
if (version_compare(PHP_VERSION, '8.1.0', '<')) {
    fwrite(STDERR, "ERROR: PHP 8.1+ is required. Found " . PHP_VERSION . "\n");
    exit(1);
}
echo "[OK] PHP " . PHP_VERSION . "\n";

// 2. Check Extensions
$requiredExts = ['pdo_mysql', 'mbstring', 'fileinfo', 'openssl', 'json'];
$missing = array_filter($requiredExts, fn($ext) => !extension_loaded($ext));
if ($missing) {
    fwrite(STDERR, "ERROR: Missing PHP extensions: " . implode(', ', $missing) . "\n");
    exit(1);
}
echo "[OK] Required PHP extensions loaded (" . implode(', ', $requiredExts) . ")\n";

// 3. Create .env from .env.example if missing
$root = __DIR__;
$envFile = $root . '/.env';
$exampleFile = $root . '/.env.example';
if (!is_file($envFile) && is_file($exampleFile)) {
    copy($exampleFile, $envFile);
    echo "[OK] Created .env from .env.example\n";
}

// 4. Create storage directories
foreach (['storage/uploads', 'storage/logs', 'storage/mail'] as $dir) {
    $full = $root . '/' . $dir;
    if (!is_dir($full)) {
        mkdir($full, 0775, true);
    }
}
echo "[OK] Storage directories ready\n";

// 5. Bootstrap & Load Env
require_once $root . '/app/bootstrap.php';
use App\Core\Env;

$host = Env::get('DB_HOST', '127.0.0.1');
$port = Env::get('DB_PORT', '3306');
$dbName = Env::get('DB_NAME', 'epap_db');
$user = Env::get('DB_USER', 'root');
$pass = Env::get('DB_PASS', '');

// 6. Connect to MySQL server & run schema.sql
try {
    $pdo = new PDO("mysql:host={$host};port={$port};charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);
    $schemaSql = file_get_contents($root . '/database/schema.sql');
    if ($schemaSql === false) {
        throw new RuntimeException('Cannot read database/schema.sql');
    }
    $pdo->exec($schemaSql);
    echo "[OK] Database '{$dbName}' and schema initialized\n";
} catch (Throwable $e) {
    fwrite(STDERR, "ERROR: Database setup failed: " . $e->getMessage() . "\n");
    fwrite(STDERR, "Check DB_HOST, DB_PORT, DB_USER, DB_PASS in .env and ensure MySQL 8 is running.\n");
    exit(1);
}

// 7. Run Seeder
require_once $root . '/database/seed.php';
$appPdo = App\Core\Database::getConnection();
runSeed($appPdo);
echo "[OK] Demo data seeded (idempotent)\n";

echo "\n=== Setup Complete! ===\n";
echo "Start server: php -S localhost:3000 router.php\n";
echo "Open portal:  http://localhost:3000/login.html\n\n";
echo "Demo Credentials:\n";
echo "  Student : ZCOER-IT-2023-042 / ZCOER-IT-2023-042\n";
echo "  Faculty : ZCOER-FAC-IT-102  / zeal_faculty_pass\n";
echo "  HOD/Adm : ZCOER-HOD-IT      / zeal_hod_secure\n";
